extends Node2D

const W := 720.0
const H := 1280.0
const PLAYER_Y := 1100.0
const PLAYER_SIZE := 80.0

var player_x := 360.0
var blocks: Array = []
var score := 0.0
var best := 0
var spawn_t := 0.0
var alive := true
var font: Font


func _ready() -> void:
	font = ThemeDB.fallback_font
	randomize()


func _restart() -> void:
	blocks.clear()
	score = 0.0
	spawn_t = 0.0
	alive = true


func _input(e: InputEvent) -> void:
	if e is InputEventMouseButton and e.pressed:
		if not alive:
			_restart()
		player_x = get_global_mouse_position().x
	elif e is InputEventMouseMotion and (e.button_mask & MOUSE_BUTTON_MASK_LEFT) != 0:
		player_x = get_global_mouse_position().x


func _process(delta: float) -> void:
	if alive:
		score += delta * 10.0
		spawn_t -= delta
		if spawn_t <= 0.0:
			spawn_t = max(0.25, 0.8 - score * 0.002)
			var size := randf_range(50.0, 120.0)
			blocks.append({
				"r": Rect2(randf_range(0.0, W - size), -size, size, size),
				"v": randf_range(300.0, 500.0) + score * 2.0
			})
		player_x = clamp(player_x, PLAYER_SIZE / 2.0, W - PLAYER_SIZE / 2.0)
		var prect := Rect2(player_x - PLAYER_SIZE / 2.0, PLAYER_Y, PLAYER_SIZE, PLAYER_SIZE)
		for i in range(blocks.size() - 1, -1, -1):
			var b = blocks[i]
			b["r"].position.y += b["v"] * delta
			if b["r"].position.y > H:
				blocks.remove_at(i)
			elif b["r"].intersects(prect):
				alive = false
				best = max(best, int(score))
	queue_redraw()


func _draw() -> void:
	draw_rect(Rect2(0, 0, W, H), Color(0.08, 0.09, 0.14))
	for b in blocks:
		draw_rect(b["r"], Color(0.95, 0.35, 0.3))
	var pc := Color(0.3, 0.85, 0.5) if alive else Color(0.5, 0.5, 0.5)
	draw_rect(Rect2(player_x - PLAYER_SIZE / 2.0, PLAYER_Y, PLAYER_SIZE, PLAYER_SIZE), pc)
	draw_string(font, Vector2(30, 70), "Score: %d" % int(score), HORIZONTAL_ALIGNMENT_LEFT, -1, 48)
	draw_string(font, Vector2(30, 125), "Best: %d" % best, HORIZONTAL_ALIGNMENT_LEFT, -1, 36)
	if not alive:
		draw_string(font, Vector2(0, 560), "GAME OVER", HORIZONTAL_ALIGNMENT_CENTER, W, 80)
		draw_string(font, Vector2(0, 650), "Tap to restart", HORIZONTAL_ALIGNMENT_CENTER, W, 44)
